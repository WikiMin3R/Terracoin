Sample configuration files for:

SystemD: terracoind.service
Upstart: terracoind.conf
OpenRC:  terracoind.openrc
         terracoind.openrcconf
CentOS:  terracoind.init
OS X:    org.terracoin.terracoind.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
